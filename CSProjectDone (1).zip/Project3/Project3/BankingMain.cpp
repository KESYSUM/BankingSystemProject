/*
 * Kayden Sysum
 * CS 210
 * 2/8/2025
 * BankingMain.cpp
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <stdexcept>
#include "Banking.h"

using namespace std;

void DisplayMenu(Banking& userInvestment);
int ValidateIntInput();
double ValidateDoubleInput();

int main() {
    Banking userInvestment;
    char userChoice = 'a';
    while (userChoice != 'q') {
        system("cls");
        DisplayMenu(userInvestment);

        userInvestment.ComputeBalanceWithoutMonthlyDeposit();
        userInvestment.ComputeBalanceWithMonthlyDeposit();

        cout << "Enter 'q' to quit or any other key to run another report: ";
        cin >> userChoice;
    }
    return 0;
}

void DisplayMenu(Banking& userInvestment) {
    try {
        double initialDeposit, monthlyDeposit, annualRate;
        int years;

        cout << "**********************************" << endl;
        cout << "********** Data Input ************" << endl;
        cout << "Initial Investment Amount: $";
        initialDeposit = ValidateDoubleInput();
        if (initialDeposit < 0) throw runtime_error("Invalid entry.");
        userInvestment.SetInitialDeposit(initialDeposit);

        cout << "Monthly Deposit: $";
        monthlyDeposit = ValidateDoubleInput();
        if (monthlyDeposit < 0) throw runtime_error("Invalid entry.");
        userInvestment.SetMonthlyDeposit(monthlyDeposit);

        cout << "Annual Interest Rate (%): ";
        annualRate = ValidateDoubleInput();
        if (annualRate < 0) throw runtime_error("Invalid entry.");
        userInvestment.SetAnnualInterestRate(annualRate);

        cout << "Number of Years: ";
        years = ValidateIntInput();
        if (years <= 0) throw runtime_error("Invalid entry.");
        userInvestment.SetInvestmentDuration(years);

        system("PAUSE");
    }
    catch (runtime_error& error) {
        cout << error.what() << endl;
        cout << "Cannot process negative values.\n";
        system("PAUSE");
        system("cls");
        DisplayMenu(userInvestment);
    }
}

int ValidateIntInput() {
    int value;
    while (!(cin >> value)) {
        cout << "Invalid input! Please enter a numerical value: ";
        cin.clear();
        while (cin.get() != '\n');
    }
    return value;
}

double ValidateDoubleInput() {
    double value;
    while (!(cin >> value)) {
        cout << "Invalid input! Please enter a valid number: ";
        cin.clear();
        while (cin.get() != '\n');
    }
    return value;
}
