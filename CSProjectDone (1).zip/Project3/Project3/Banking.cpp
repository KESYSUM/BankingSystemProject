/*
 * Kayden Sysum
 * CS 210
 * 2/8/2025
 * Banking.cpp
 */

#include "Banking.h"
#include <iostream>
#include <iomanip>

using namespace std;

// Banking class definition

// Setters (Mutators)
void Banking::SetInitialDeposit(double initialDeposit) {
    totalBalance = initialDeposit;
}
void Banking::SetMonthlyDeposit(double monthlyDeposit) {
    depositPerMonth = monthlyDeposit;
}
void Banking::SetAnnualInterestRate(double annualRate) {
    yearlyInterestRate = annualRate;
}
void Banking::SetInvestmentDuration(int years) {
    investmentYears = years;
}

// Getters (Accessors)
double Banking::GetInitialDeposit() const {
    return totalBalance;
}
double Banking::GetMonthlyDeposit() const {
    return depositPerMonth;
}
double Banking::GetAnnualInterestRate() const {
    return yearlyInterestRate;
}
int Banking::GetInvestmentDuration() const {
    return investmentYears;
}

// Function to calculate and display balance without monthly deposits
double Banking::ComputeBalanceWithoutMonthlyDeposit() {
    double currentBalance = totalBalance;

    cout << "\n     Balance and Interest Without Monthly Deposits" << endl;
    cout << string(70, '=') << endl;
    cout << "Year          End Balance          Earned Interest" << endl;
    cout << string(70, '-') << endl;

    for (int i = 0; i < investmentYears; i++) {
        double interestAmount = currentBalance * (yearlyInterestRate / 100);
        currentBalance += interestAmount;
        cout << " " << left << setw(5) << (i + 1) << "\t\t$" << fixed << setprecision(2) << currentBalance
            << "\t\t\t$" << interestAmount << endl;
    }
    return currentBalance;
}

// Function to calculate and display balance with monthly deposits
double Banking::ComputeBalanceWithMonthlyDeposit() {
    double currentBalance = totalBalance;

    cout << "\n     Balance and Interest With Monthly Deposits" << endl;
    cout << string(70, '=') << endl;
    cout << "Year          End Balance          Earned Interest" << endl;
    cout << string(70, '-') << endl;

    for (int i = 0; i < investmentYears; i++) {
        double yearlyTotalInterest = 0;
        for (int j = 0; j < 12; j++) {
            double interestAmount = (currentBalance + depositPerMonth) * ((yearlyInterestRate / 100) / 12);
            yearlyTotalInterest += interestAmount;
            currentBalance += depositPerMonth + interestAmount;
        }
        cout << " " << left << setw(5) << (i + 1) << "\t\t$" << fixed << setprecision(2) << currentBalance
            << "\t\t\t$" << yearlyTotalInterest << endl;
    }
    return currentBalance;
}
